#Energistics Transfer Protocol

The Energistics Transfer Protocol (ETP) is a specification for an asynchronous message-based data transfer standard used by the Energistics family data formats. This project contains the following artifacts:

1. The UML models for the specification in XML form as well as a Sparx EA model.
2. Generated documentation for these models
3. Generated schemas files (.avsc and/or .xsd) for protocol messages.
4. A feedback form to capture and submit your comments and issues during your ETP testing.

Refer to the bitbucket repositories at https://bitbucket.org/energistics for more information.