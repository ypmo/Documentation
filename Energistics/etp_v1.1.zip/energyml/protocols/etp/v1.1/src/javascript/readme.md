The javascript files (both server and browser version) for ETP are supplied via nodejs and npm.

use:

$npm install etp 

to get the latest version